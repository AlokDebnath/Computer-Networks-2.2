rm file1.txt
rm file2.txt
gcc fileclient.c
./a.out
