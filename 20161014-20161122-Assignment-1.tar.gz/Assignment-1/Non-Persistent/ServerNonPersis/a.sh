gcc fileserver.c
./a.out

